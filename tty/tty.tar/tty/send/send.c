//send.c
      #include <stdio.h>
      #include <string.h>
      #include <malloc.h>
      #include <sys/types.h>
      #include <sys/stat.h>
      #include <fcntl.h>
      #include <unistd.h>
      #include <termios.h>

      #define MAX_BUFFER_SIZE 512

      int fd, flag_close;

      int open_serial()
      {
            //�����/dev/pts/1��ʹ��mkptych.py�����������������֮һ
            fd = open("/dev/pts/5", O_RDWR | O_NOCTTY | O_NONBLOCK);
            if(fd == -1)
            {
                  perror("open serial port error!\n");
                  return -1;
            }

            printf("Open serial port success!");
            return 0;
      }

      int main(int argc, char* argv[])
      {
            char sbuf[] = {"Hello, this is a serial port test!\n"};
            int retv;
            struct termios option;

            retv = open_serial();
            if(retv < 0)
            {
                  perror("open serial port error!\n");
                  return -1;
            }

            printf("Ready for sending data...\n");

            tcgetattr(fd, &option);
            cfmakeraw(&option);

            cfsetispeed(&option, B9600);
            cfsetospeed(&option, B9600);

            tcsetattr(fd, TCSANOW, &option);

			while(1)
				{
					int length = sizeof(sbuf);
		         	retv = write(fd, sbuf, length);
		            if(retv == -1)
		            {
		                  perror("Write data error!\n");
		                  return -1;
		            }
					

		            printf("The number of char sent is %d\n", retv);
					sleep(1);
				}
            
            return 0;
      }

